import os
import re
import time
import sqlite3
from collections import defaultdict, deque
from datetime import datetime, timedelta, timezone
from typing import Optional

from aiogram import Bot, Dispatcher, F, Router
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode, ChatMemberStatus
from aiogram.filters import CommandStart, Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.types import (
    Message, CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup,
    ReplyKeyboardMarkup, KeyboardButton, ReplyKeyboardRemove, ChatPermissions
)
from dotenv import load_dotenv

load_dotenv()

TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "").strip()
ADMIN_CHAT_ID = os.getenv("ADMIN_CHAT_ID", "").strip()
BRAND_NAME = os.getenv("BRAND_NAME", "بوت أبو دره الشريف").strip()
DB_PATH = os.getenv("DB_PATH", "abudorh_bot.db")

PROBATION_HOURS = int(os.getenv("PROBATION_HOURS", "24"))
PROBATION_SAFE_MESSAGES = int(os.getenv("PROBATION_SAFE_MESSAGES", "5"))
MAX_WARNINGS = int(os.getenv("MAX_WARNINGS", "2"))
MUTE_MINUTES = int(os.getenv("MUTE_MINUTES", "60"))
FLOOD_MAX = int(os.getenv("FLOOD_MAX", "6"))
FLOOD_WINDOW_SECONDS = int(os.getenv("FLOOD_WINDOW_SECONDS", "10"))

if not TOKEN:
    raise RuntimeError("ضع TELEGRAM_BOT_TOKEN في ملف .env")

bot = Bot(TOKEN, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
dp = Dispatcher(storage=MemoryStorage())
router = Router()
dp.include_router(router)

flood_cache = defaultdict(lambda: deque(maxlen=30))

SEXUAL_PATTERNS = [
    r"\b(?:porn|porno|xxx|sex|sexy|nude|nudes|onlyfans|escort)\b",
    r"(?:اباحي|إباحي|اباحية|إباحية|جنس(?:ي|ية)?|عاري|عارية|صور\s*عاري|فيديو\s*اباح)",
    r"(?:سكس|نيك|زب|كس|طيز|ممحون|ممحونة|علاقات\s*جنسية)",
]

AD_PATTERNS = [
    r"(?:اعلان|إعلان|دعاية|ترويج|عرض\s*خاص|خصم\s*حصري|احجز\s*الآن|حجز\s*الآن)",
    r"(?:راسلني\s*خاص|تواصل\s*خاص|واتساب|واتس\s*اب|للبيع|للإيجار|للايجار)",
    r"(?:انضم\s*إلى|انضم\s*الى|قناتنا|مجموعتنا|تابعنا|أفضل\s*الأسعار|افضل\s*الاسعار)",
    r"(?:خدماتنا|متوفر\s*لدينا|نقدم\s*خدمة|يوجد\s*لدينا)",
]

SEXUAL_RE = re.compile("|".join(f"(?:{x})" for x in SEXUAL_PATTERNS), re.I)
AD_RE = re.compile("|".join(f"(?:{x})" for x in AD_PATTERNS), re.I)
URL_RE = re.compile(r"https?://\S+|www\.\S+|t\.me/\S+|telegram\.me/\S+", re.I)
PHONE_RE = re.compile(r"(?<!\d)(?:\+?\d[\d\-\s\(\)]{7,}\d)(?!\d)")

# قاعدة سياحية عامة أولية
GENERAL_TOURISM = {
    "البوسنة": "البوسنة مناسبة للطبيعة والأنهار والجبال والمدن التاريخية، ومن أشهر محطاتها سراييفو وموستار ويايتسى وبيهاتش.",
    "تركيا": "تركيا مناسبة للعائلات والتسوق والطبيعة، ومن أشهر الوجهات إسطنبول وطرابزون وبورصة وأنطاليا.",
    "جورجيا": "جورجيا مناسبة للطبيعة والجبال، ومن أشهر الوجهات تبليسي وباتومي وكازبيجي وبورجومي.",
    "كازاخستان": "كازاخستان مناسبة للطبيعة والجبال، وألماتي من أبرز المدن السياحية فيها.",
    "أذربيجان": "أذربيجان تجمع بين باكو والطبيعة الجبلية في قبالا وشكي.",
    "تايلند": "تايلند مناسبة للشواطئ والمنتجعات، ومن أشهر الوجهات بانكوك وبوكيت وكرابي.",
    "ماليزيا": "ماليزيا مناسبة للعائلات والطبيعة، ومن أشهر الوجهات كوالالمبور ولنكاوي وبينانغ.",
    "اندونيسيا": "إندونيسيا مناسبة للطبيعة والجزر، ومن أشهر الوجهات بالي وجاكرتا وبونشاك.",
    "إندونيسيا": "إندونيسيا مناسبة للطبيعة والجزر، ومن أشهر الوجهات بالي وجاكرتا وبونشاك.",
}

SERVICES = {
    "car": "🚗 تأجير سيارة",
    "stay": "🏡 سكن / فيلا / شقة",
    "hotel": "🏨 فندق",
    "program": "🗺 برنامج سياحي",
    "driver": "🚐 سائق / نقل",
    "visa": "🛂 تأشيرة",
    "esim": "📱 شريحة eSIM",
    "ticket": "✈️ تذاكر سفر",
    "other": "💬 خدمة أخرى",
}

class RequestFlow(StatesGroup):
    service = State()
    destination = State()
    date = State()
    travelers = State()
    details = State()
    phone = State()

def db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with db() as conn:
        conn.execute("""
        CREATE TABLE IF NOT EXISTS members(
            chat_id INTEGER, user_id INTEGER, joined_at INTEGER,
            safe_messages INTEGER DEFAULT 0, warnings INTEGER DEFAULT 0,
            PRIMARY KEY(chat_id,user_id)
        )""")
        conn.execute("""
        CREATE TABLE IF NOT EXISTS incidents(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            chat_id INTEGER,user_id INTEGER,reason TEXT,action TEXT,
            created_at TEXT
        )""")
        conn.execute("""
        CREATE TABLE IF NOT EXISTS requests(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            request_no TEXT UNIQUE,
            telegram_user_id INTEGER,
            service TEXT,destination TEXT,travel_date TEXT,
            travelers TEXT,details TEXT,phone TEXT,status TEXT,
            created_at TEXT
        )""")
        conn.commit()

def ensure_member(chat_id, user_id):
    with db() as conn:
        conn.execute(
            "INSERT OR IGNORE INTO members(chat_id,user_id,joined_at) VALUES(?,?,?)",
            (chat_id,user_id,int(time.time()))
        )
        conn.commit()

def increment_safe(chat_id,user_id):
    ensure_member(chat_id,user_id)
    with db() as conn:
        conn.execute("UPDATE members SET safe_messages=safe_messages+1 WHERE chat_id=? AND user_id=?",
                     (chat_id,user_id))
        conn.commit()

def warning(chat_id,user_id):
    ensure_member(chat_id,user_id)
    with db() as conn:
        conn.execute("UPDATE members SET warnings=warnings+1 WHERE chat_id=? AND user_id=?",
                     (chat_id,user_id))
        conn.commit()
        return int(conn.execute("SELECT warnings FROM members WHERE chat_id=? AND user_id=?",
                                (chat_id,user_id)).fetchone()["warnings"])

def probation(chat_id,user_id):
    ensure_member(chat_id,user_id)
    with db() as conn:
        row = conn.execute("SELECT * FROM members WHERE chat_id=? AND user_id=?",
                           (chat_id,user_id)).fetchone()
    return (time.time() - row["joined_at"] < PROBATION_HOURS*3600
            and row["safe_messages"] < PROBATION_SAFE_MESSAGES)

async def is_admin(message: Message):
    try:
        m = await bot.get_chat_member(message.chat.id, message.from_user.id)
        return m.status in {ChatMemberStatus.ADMINISTRATOR, ChatMemberStatus.CREATOR}
    except Exception:
        return False

def has_media(message):
    return bool(message.photo or message.video or message.animation or
                message.document or message.sticker or message.video_note)

def detect_violation(message: Message) -> Optional[str]:
    text = (message.text or message.caption or "").strip()
    if not text:
        return None
    if SEXUAL_RE.search(text):
        return "محتوى أو إيحاء جنسي/إباحي"
    if AD_RE.search(text):
        return "إعلان أو ترويج غير مصرح"
    if URL_RE.search(text) and ("t.me/" in text.lower() or "telegram.me/" in text.lower()):
        return "رابط قناة أو مجموعة دعائي"
    if PHONE_RE.search(text) and any(x in text.lower() for x in ["واتس","تواصل","حجز","عرض","خاص"]):
        return "إعلان يتضمن وسيلة تواصل"
    return None

def is_flood(message):
    key=(message.chat.id,message.from_user.id)
    now=time.time()
    q=flood_cache[key]
    q.append(now)
    while q and now-q[0] > FLOOD_WINDOW_SECONDS:
        q.popleft()
    return len(q) >= FLOOD_MAX

async def mute(chat_id,user_id):
    perms=ChatPermissions(can_send_messages=False)
    await bot.restrict_chat_member(
        chat_id,user_id,permissions=perms,
        until_date=datetime.now(timezone.utc)+timedelta(minutes=MUTE_MINUTES)
    )

async def punish(message, reason):
    try:
        await message.delete()
    except:
        pass
    n=warning(message.chat.id,message.from_user.id)
    action="حذف الرسالة"
    try:
        if n >= MAX_WARNINGS:
            await bot.ban_chat_member(message.chat.id,message.from_user.id)
            action="حظر العضو"
        else:
            await mute(message.chat.id,message.from_user.id)
            action=f"كتم {MUTE_MINUTES} دقيقة"
    except:
        pass
    with db() as conn:
        conn.execute("INSERT INTO incidents(chat_id,user_id,reason,action,created_at) VALUES(?,?,?,?,?)",
                     (message.chat.id,message.from_user.id,reason,action,datetime.now().isoformat()))
        conn.commit()
    if ADMIN_CHAT_ID:
        try:
            await bot.send_message(int(ADMIN_CHAT_ID),
                f"🛡 <b>مخالفة جديدة</b>\nالعضو: {message.from_user.full_name}\n"
                f"السبب: {reason}\nالإجراء: {action}")
        except:
            pass

def tourism_answer(text: str) -> Optional[str]:
    low = text.lower()

    for country, ans in GENERAL_TOURISM.items():
        if country.lower() in low:
            return f"🌍 <b>{country}</b>\n{ans}\n\nإذا ذكرت لي عدد الأيام والميزانية ونوع الرحلة أرتب لك اقتراحًا أدق."

    if any(x in low for x in ["وين اسافر","وين أسافر","اقترح وجهة","أفضل دولة","افضل دولة"]):
        return (
            "✈️ أقدر أساعدك باختيار الوجهة المناسبة.\n"
            "أرسل لي: شهر السفر + عدد الأيام + عدد المسافرين + الميزانية التقريبية + هل تفضل طبيعة أو مدن أو شواطئ."
        )

    if any(x in low for x in ["برنامج سياحي","جدول سفر","رتب لي رحلة","رتب رحلة"]):
        return (
            "🗺 أرسل لي الدولة، عدد الأيام، عدد المسافرين وموعد الرحلة، "
            "وسأقترح لك توزيعًا مناسبًا للمدن والأنشطة."
        )

    return None

def service_keyboard():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=v,callback_data=f"svc:{k}")] for k,v in SERVICES.items()
    ])

@router.message(CommandStart())
async def start(message: Message):
    kb=InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🌍 اسأل المساعد السياحي", callback_data="tourism_help")],
        [InlineKeyboardButton(text="📩 طلب خدمة سياحية", callback_data="new_request")],
    ])
    await message.answer(
        f"أهلًا بك في <b>{BRAND_NAME}</b> ✈️\n\n"
        "مساعد سياحي عام للوجهات والسفر، ويعمل في المجموعات أيضًا كنظام حماية ومراقبة.",
        reply_markup=kb
    )

@router.callback_query(F.data=="tourism_help")
async def tourism_help(cb: CallbackQuery):
    await cb.message.answer(
        "اسألني مباشرة مثل:\n"
        "• وين أسافر في أكتوبر؟\n"
        "• اقترح لي برنامج 8 أيام في البوسنة\n"
        "• وش الأفضل للعائلة: تركيا أو جورجيا؟"
    )
    await cb.answer()

@router.callback_query(F.data=="new_request")
async def req_start(cb: CallbackQuery,state:FSMContext):
    await state.clear()
    await state.set_state(RequestFlow.service)
    await cb.message.answer("اختر نوع الخدمة:",reply_markup=service_keyboard())
    await cb.answer()

@router.callback_query(RequestFlow.service,F.data.startswith("svc:"))
async def req_service(cb:CallbackQuery,state:FSMContext):
    key=cb.data.split(":",1)[1]
    await state.update_data(service=SERVICES[key])
    await state.set_state(RequestFlow.destination)
    await cb.message.answer("ما الدولة أو المدينة المطلوبة؟")
    await cb.answer()

@router.message(RequestFlow.destination)
async def req_dest(m:Message,state:FSMContext):
    await state.update_data(destination=m.text or "")
    await state.set_state(RequestFlow.date)
    await m.answer("ما موعد السفر؟")

@router.message(RequestFlow.date)
async def req_date(m:Message,state:FSMContext):
    await state.update_data(travel_date=m.text or "")
    await state.set_state(RequestFlow.travelers)
    await m.answer("كم عدد المسافرين؟")

@router.message(RequestFlow.travelers)
async def req_people(m:Message,state:FSMContext):
    await state.update_data(travelers=m.text or "")
    await state.set_state(RequestFlow.details)
    await m.answer("اكتب تفاصيل الطلب باختصار.")

@router.message(RequestFlow.details)
async def req_details(m:Message,state:FSMContext):
    await state.update_data(details=m.text or "")
    await state.set_state(RequestFlow.phone)
    kb=ReplyKeyboardMarkup(
        keyboard=[[KeyboardButton(text="📲 إرسال رقم الجوال",request_contact=True)]],
        resize_keyboard=True,one_time_keyboard=True
    )
    await m.answer("أرسل رقم الجوال للتواصل:",reply_markup=kb)

@router.message(RequestFlow.phone,F.contact)
async def req_phone_contact(m:Message,state:FSMContext):
    await finish_request(m,state,m.contact.phone_number)

@router.message(RequestFlow.phone)
async def req_phone_text(m:Message,state:FSMContext):
    await finish_request(m,state,m.text or "")

async def finish_request(m:Message,state:FSMContext,phone):
    data=await state.get_data()
    with db() as conn:
        cur=conn.execute("""INSERT INTO requests(
            request_no,telegram_user_id,service,destination,travel_date,
            travelers,details,phone,status,created_at
        ) VALUES(?,?,?,?,?,?,?,?,?,?)""",
        ("PENDING",m.from_user.id,data["service"],data["destination"],data["travel_date"],
         data["travelers"],data["details"],phone,"new",datetime.now().isoformat()))
        rid=cur.lastrowid
        reqno=f"AD-{datetime.now():%y%m%d}-{rid:04d}"
        conn.execute("UPDATE requests SET request_no=? WHERE id=?",(reqno,rid))
        conn.commit()

    await state.clear()
    await m.answer(
        f"✅ تم استلام طلبك\nرقم الطلب: <code>{reqno}</code>\n"
        "سيتم تحويله للجهة المختصة.",
        reply_markup=ReplyKeyboardRemove()
    )

    if ADMIN_CHAT_ID:
        try:
            await bot.send_message(int(ADMIN_CHAT_ID),
                f"📩 <b>طلب سياحي جديد</b>\n"
                f"رقم الطلب: <code>{reqno}</code>\n"
                f"الخدمة: {data['service']}\n"
                f"الوجهة: {data['destination']}\n"
                f"الموعد: {data['travel_date']}\n"
                f"المسافرون: {data['travelers']}\n"
                f"التفاصيل: {data['details']}\n"
                f"الجوال: {phone}")
        except:
            pass

@router.message(F.new_chat_members)
async def joins(m:Message):
    for u in m.new_chat_members:
        if not u.is_bot:
            ensure_member(m.chat.id,u.id)

@router.message(Command("guard_status"))
async def guard_status(m:Message):
    await m.answer(
        "🛡 الحماية تعمل\n"
        f"فترة حماية العضو الجديد: {PROBATION_HOURS} ساعة\n"
        f"عدد المخالفات قبل الحظر: {MAX_WARNINGS}"
    )

@router.message()
async def all_messages(m:Message):
    if not m.from_user or m.from_user.is_bot:
        return

    if m.chat.type in {"group","supergroup"}:
        if not await is_admin(m):
            ensure_member(m.chat.id,m.from_user.id)

            violation=detect_violation(m)
            if violation:
                return await punish(m,violation)

            if probation(m.chat.id,m.from_user.id):
                if has_media(m):
                    try: await m.delete()
                    except: pass
                    return
                if URL_RE.search(m.text or m.caption or ""):
                    try: await m.delete()
                    except: pass
                    return

            if is_flood(m):
                return await punish(m,"إغراق/رسائل متتابعة بسرعة")

            increment_safe(m.chat.id,m.from_user.id)

    text=(m.text or "").strip()
    if text:
        ans=tourism_answer(text)
        if ans:
            await m.reply(ans)

async def main():
    init_db()
    print(f"{BRAND_NAME} is running...")
    await dp.start_polling(bot)

if __name__=="__main__":
    import asyncio
    asyncio.run(main())
